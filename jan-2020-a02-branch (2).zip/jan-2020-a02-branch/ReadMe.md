# DMIT1530 In-Class #1 - Flexbox [Jan 24]

## Instructions
1. Downlaod the **lab document** file and follow the directions contained within. The starting files are also found in the **in-class-1.zip** file.

1. Create a working branch (name does not matter).
1. Do your work on your working branch.
1. While coding, commit often.
1. When completed, or out of time, merge your working branch into your **master** branch.
1. Commit **master** branch to the assignment repository.
1. Compress your project folder to a **ZIP** file, which you will upload to Moodle.


>**Note**: You **MUST** be present in class in order to receive a grade for this assessment.
