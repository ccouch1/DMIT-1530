# DMIT1530-A02 - First Build Activity

## Introduction
This activity is **NOT** a graded assignment; it is a practice assignment as a review of concepts taught in COMP1017.

1. Download the resource files and create the home page to match the supplied wireframe (i.e. Photoshop file).
1. Download nd extract the **center-page-framewordk.zip** file (only necessary if you do not have a copy of the framework from COMP1017, or you want a freash copy).
1. Start your build; complete as much as you can.
1. Commit your changes to the activity URL.

>**Note**: You will start this activity on your own. During trhe first two weeks of the semester we (in-class) will complete this build. The purposes of this acitivity is to see what you remember from COMP1017, refine techniques/comcepts taught in COMP1017, and to introduce Git and GitHUb as a means of version control of future builds in DMIT1530.

![Funny](https://imgs.xkcd.com/comics/server_attention_span.png)
