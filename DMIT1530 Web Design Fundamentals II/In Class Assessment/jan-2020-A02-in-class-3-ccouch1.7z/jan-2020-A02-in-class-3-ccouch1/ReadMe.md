# DMIT1530 In-Class #3

## Instructions
They are the text of the index.html page ... follow them closely!

## Submission
When completed do the following:
 1. ZIP your web solution folder and upload to Moodle
 1. Push your work to the GitHub Repository
